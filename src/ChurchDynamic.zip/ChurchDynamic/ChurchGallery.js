import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';

const ChurchGallery = () => {
  const [gallery, setGallery] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null);

  useEffect(() => {
    fetchGallery();
  }, []);

  const fetchGallery = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/gallery');
      setGallery(res.data);
      setLoading(false);
    } catch (err) {
      console.error('Failed to fetch gallery:', err);
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    const confirm = window.confirm("Are you sure you want to delete this image?");
    if (!confirm) return;

    try {
      setDeleting(id);
      await axios.delete(`http://localhost:5000/api/gallery/${id}`);
      setGallery((prev) => prev.filter((img) => img._id !== id));
      setDeleting(null);
    } catch (err) {
      console.error('Delete error:', err);
      setDeleting(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 py-10 px-6">
      <h1 className="text-4xl font-bold text-center text-purple-800 mb-10 drop-shadow-md">📸 Church Gallery</h1>

      {loading ? (
        <p className="text-center text-lg">Loading...</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          <AnimatePresence>
            {gallery.map((img) => (
              <motion.div
                key={img._id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative group shadow-xl rounded-lg overflow-hidden bg-white"
              >
                <img
                  src={`http://localhost:5000${img.path}`}
                  alt="Gallery"
                  className="w-full h-64 object-cover transform transition-transform duration-300 group-hover:scale-105"
                />
                <button
                  onClick={() => handleDelete(img._id)}
                  disabled={deleting === img._id}
                  className="absolute top-2 right-2 bg-red-600 hover:bg-red-800 text-white px-3 py-1 text-sm rounded shadow-md transition-all duration-200"
                >
                  {deleting === img._id ? "Deleting..." : "Delete"}
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default ChurchGallery;
