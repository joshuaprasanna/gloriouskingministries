// src/Church/ChurchGalleryPage.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';

const ChurchGalleryPage = () => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/gallery')
      .then(res => setImages(res.data))
      .catch(err => console.error('Failed to fetch gallery:', err));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 p-8">
      <h1 className="text-4xl font-bold text-center text-purple-800 mb-10">
        📸 Glorious Gallery
      </h1>

      {images.length === 0 ? (
        <p className="text-center text-gray-500">No images uploaded yet.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {images.map((img, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:scale-105 transition duration-300 bg-white"
            >
              <img
                src={`http://localhost:5000/uploads/${img.filename}`}
                alt={`gallery-img-${index}`}
                className="w-full h-64 object-cover"
              />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ChurchGalleryPage;
