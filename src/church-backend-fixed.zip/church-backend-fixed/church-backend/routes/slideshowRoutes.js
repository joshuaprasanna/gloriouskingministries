const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');
const { uploadSlideshowImage, getSlideshowImages } = require('../controllers/slideshowController');
const verifyToken = require('../middleware/auth');

router.post('/upload', verifyToken, upload.single('image'), uploadSlideshowImage);
router.get('/', getSlideshowImages);

module.exports = router;
