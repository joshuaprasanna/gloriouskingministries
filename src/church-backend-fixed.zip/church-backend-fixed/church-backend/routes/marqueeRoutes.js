const express = require('express');
const router = express.Router();
const { postMarquee, getMarquees } = require('../controllers/marqueeController');
const verifyToken = require('../middleware/auth');

router.post('/', verifyToken, postMarquee);
router.get('/', getMarquees);

module.exports = router;
