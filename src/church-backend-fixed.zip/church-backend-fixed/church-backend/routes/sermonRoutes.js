const express = require('express');
const router = express.Router();
const { uploadSermon, getSermons } = require('../controllers/sermonController');
const verifyToken = require('../middleware/auth');

router.post('/', verifyToken, uploadSermon);
router.get('/', getSermons);

module.exports = router;
