// routes/galleryRoutes.js
const express = require('express');
const router = express.Router();

// Middleware
const verifyToken = require('../middleware/auth');
const upload = require('../middleware/upload'); // ✅ use separate upload middleware

// Controller
const {
  uploadGalleryImage,
  getGalleryImages,
  deleteGalleryImage
} = require('../controllers/galleryController');

// Routes
router.post('/upload', verifyToken, upload.single('image'), uploadGalleryImage);
router.get('/', getGalleryImages);
router.delete('/:id', verifyToken, deleteGalleryImage);

module.exports = router;
