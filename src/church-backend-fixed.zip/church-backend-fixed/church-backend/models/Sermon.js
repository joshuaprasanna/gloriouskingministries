const mongoose = require('mongoose');

const sermonSchema = new mongoose.Schema({
  title: { type: String, required: true },
  videoUrl: { type: String, required: true }, // or use file path if uploading
  uploadedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Sermon', sermonSchema);
