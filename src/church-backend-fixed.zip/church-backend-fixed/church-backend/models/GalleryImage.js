// const mongoose = require('mongoose');

// const GalleryImageSchema = new mongoose.Schema({
//   filename: String,
//   path: String,
//   uploadedAt: {
//     type: Date,
//     default: Date.now,
//   },
// });

// module.exports = mongoose.model('GalleryImage', GalleryImageSchema);
const mongoose = require('mongoose');

const galleryImageSchema = new mongoose.Schema({
  imageUrl: { type: String, required: true },
  uploadedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('GalleryImage', galleryImageSchema);

