// // server.js
// const express = require('express');
// const mongoose = require('mongoose');
// const dotenv = require('dotenv');
// const cors = require('cors');
// const multer = require('multer');
// const path = require('path');
// const fs = require('fs');

// // Load environment variables
// dotenv.config();

// const app = express();
// app.use(cors());
// app.use(express.json());
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// // MongoDB connection
// mongoose.connect(process.env.MONGO_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// }).then(() => console.log('✅ MongoDB Connected'))
//   .catch((err) => console.error('❌ MongoDB Connection Error:', err));

// // Define Mongoose model
// const GalleryImage = mongoose.model('GalleryImage', new mongoose.Schema({
//   path: String,
//   uploadedAt: {
//     type: Date,
//     default: Date.now,
//   },
// }));

// // Multer Storage Configuration
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, 'uploads/');
//   },
//   filename: (req, file, cb) => {
//     const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
//     cb(null, uniqueSuffix + path.extname(file.originalname));
//   },
// });

// const upload = multer({ storage });

// // Upload Endpoint
// app.post('/api/upload', upload.single('image'), async (req, res) => {
//   try {
//     const newImage = new GalleryImage({
//       path: `/uploads/${req.file.filename}`,
//     });
//     await newImage.save();
//     res.status(201).json({ message: 'Image uploaded successfully', image: newImage });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: 'Upload failed' });
//   }
// });

// // Get All Images
// app.get('/api/gallery', async (req, res) => {
//   try {
//     const images = await GalleryImage.find().sort({ uploadedAt: -1 });
//     res.json(images);
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to fetch gallery' });
//   }
// });

// // Delete Image by ID
// app.delete('/api/gallery/:id', async (req, res) => {
//   try {
//     const image = await GalleryImage.findById(req.params.id);
//     if (!image) {
//       return res.status(404).json({ message: 'Image not found' });
//     }

//     // Remove file from disk
//     const filePath = path.join(__dirname, image.path);
//     if (fs.existsSync(filePath)) {
//       fs.unlinkSync(filePath);
//     }

//     // Remove from database
//     await GalleryImage.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Image deleted successfully' });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: 'Delete failed' });
//   }
// });

// // Start Server
// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//   console.log(`🚀 Server running on http://localhost:${PORT}`);
// });
// server.js
// server.js




// const express = require('express');
// const mongoose = require('mongoose');
// const dotenv = require('dotenv');
// const cors = require('cors');
// const multer = require('multer');
// const jwt = require('jsonwebtoken');
// const bcrypt = require('bcryptjs');
// const path = require('path');

// const Admin = require('./models/Admin');
// const Gallery = require('./models/Galleryimage');
// const Slider = require('./models/SlideshowImage');
// const Marquee = require('./models/MarqueeMessage');
// const Sermon = require('./models/Sermon');
// const Event = require('./models/Event');

// dotenv.config();
// const app = express();
// app.use(cors());
// app.use(express.json());
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// mongoose.connect(process.env.MONGO_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// }).then(() => console.log('✅ MongoDB connected'))
//   .catch(err => console.error('❌ MongoDB error:', err));

// // JWT Middleware
// function authenticateToken(req, res, next) {
//   const token = req.headers.authorization?.split(' ')[1];
//   if (!token) return res.status(401).json({ message: 'Access denied' });

//   jwt.verify(token, process.env.JWT_SECRET, (err, admin) => {
//     if (err) return res.status(403).json({ message: 'Invalid token' });
//     req.admin = admin;
//     next();
//   });
// }

// // Admin Login
// app.post('/api/admin/login', async (req, res) => {
//   const { email, password } = req.body;
//   try {
//     const admin = await Admin.findOne({ email });
//     if (!admin) return res.status(401).json({ message: 'Invalid email' });

//     const isMatch = await bcrypt.compare(password, admin.password);
//     if (!isMatch) return res.status(401).json({ message: 'Invalid password' });

//     const token = jwt.sign({ adminId: admin._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
//     res.json({ token });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error' });
//   }
// });

// // Multer setup for uploads
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => cb(null, 'uploads/'),
//   filename: (req, file, cb) =>
//     cb(null, `${Date.now()}-${file.originalname}`),
// });
// const upload = multer({ storage });

// // ===== Upload Routes (All Protected) =====

// // Upload to Gallery
// app.post('/api/gallery/upload', authenticateToken, upload.single('image'), async (req, res) => {
//   try {
//     const newImg = new Gallery({ imageUrl: `/uploads/${req.file.filename}`, title: req.body.title });
//     await newImg.save();
//     res.json({ message: 'Gallery image uploaded', image: newImg });
//   } catch (err) {
//     res.status(500).json({ message: 'Upload error' });
//   }
// });

// // Upload to Slider
// app.post('/api/slider/upload', authenticateToken, upload.single('image'), async (req, res) => {
//   try {
//     const newSlide = new Slider({ imageUrl: `/uploads/${req.file.filename}`, caption: req.body.caption });
//     await newSlide.save();
//     res.json({ message: 'Slider image uploaded', image: newSlide });
//   } catch (err) {
//     res.status(500).json({ message: 'Upload error' });
//   }
// });

// // Upload Marquee Message
// app.post('/api/marquee/upload', authenticateToken, async (req, res) => {
//   try {
//     const newMarquee = new Marquee({ message: req.body.message });
//     await newMarquee.save();
//     res.json({ message: 'Marquee added', marquee: newMarquee });
//   } catch (err) {
//     res.status(500).json({ message: 'Upload error' });
//   }
// });

// // Upload Sermon
// app.post('/api/sermon/upload', authenticateToken, async (req, res) => {
//   try {
//     const newSermon = new Sermon({ title: req.body.title, videoUrl: req.body.videoUrl });
//     await newSermon.save();
//     res.json({ message: 'Sermon uploaded', sermon: newSermon });
//   } catch (err) {
//     res.status(500).json({ message: 'Upload error' });
//   }
// });

// // Upload Event
// app.post('/api/event/upload', authenticateToken, async (req, res) => {
//   try {
//     const newEvent = new Event({ name: req.body.name, date: req.body.date, description: req.body.description });
//     await newEvent.save();
//     res.json({ message: 'Event uploaded', event: newEvent });
//   } catch (err) {
//     res.status(500).json({ message: 'Upload error' });
//   }
// });

// // ===== Delete Routes (All Protected) =====

// app.delete('/api/gallery/:id', authenticateToken, async (req, res) => {
//   try {
//     await Gallery.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Gallery image deleted' });
//   } catch (err) {
//     res.status(500).json({ message: 'Delete error' });
//   }
// });

// app.delete('/api/slider/:id', authenticateToken, async (req, res) => {
//   try {
//     await Slider.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Slider image deleted' });
//   } catch (err) {
//     res.status(500).json({ message: 'Delete error' });
//   }
// });

// app.delete('/api/marquee/:id', authenticateToken, async (req, res) => {
//   try {
//     await Marquee.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Marquee deleted' });
//   } catch (err) {
//     res.status(500).json({ message: 'Delete error' });
//   }
// });

// app.delete('/api/sermon/:id', authenticateToken, async (req, res) => {
//   try {
//     await Sermon.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Sermon deleted' });
//   } catch (err) {
//     res.status(500).json({ message: 'Delete error' });
//   }
// });

// app.delete('/api/event/:id', authenticateToken, async (req, res) => {
//   try {
//     await Event.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Event deleted' });
//   } catch (err) {
//     res.status(500).json({ message: 'Delete error' });
//   }
// });

// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
// server.js
// server.js
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Load environment variables
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Create "uploads" folder if it doesn't exist
const uploadsPath = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsPath)) {
  fs.mkdirSync(uploadsPath);
}

// Multer config for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsPath);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  }
});
const upload = multer({ storage });

// Serve uploaded images statically
app.use('/uploads', express.static(uploadsPath));

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('✅ MongoDB connected'))
  .catch((err) => console.error('❌ MongoDB connection error:', err));

// Gallery Schema
const Gallery = mongoose.model('Gallery', new mongoose.Schema({
  imageUrl: String,
  title: String,
  description: String
}));

// POST /api/gallery/upload
app.post('/api/gallery/upload', upload.single('image'), async (req, res) => {
  try {
    const { title, description } = req.body;
    const imageUrl = `/uploads/${req.file.filename}`;
    const newImage = new Gallery({ imageUrl, title, description });
    await newImage.save();
    res.status(201).json({ message: 'Image uploaded successfully', image: newImage });
  } catch (err) {
    res.status(500).json({ message: 'Upload failed', error: err.message });
  }
});

// GET /api/gallery
app.get('/api/gallery', async (req, res) => {
  try {
    const images = await Gallery.find().sort({ _id: -1 });
    res.json(images);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch images', error: err.message });
  }
});

// Server listening
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server is running on port ${PORT}`);
});
