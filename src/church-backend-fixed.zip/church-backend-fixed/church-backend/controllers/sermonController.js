const Sermon = require('../models/Sermon');

exports.uploadSermon = async (req, res) => {
  try {
    const newSermon = new Sermon({
      title: req.body.title,
      videoUrl: req.body.videoUrl,
    });
    await newSermon.save();
    res.status(201).json({ message: 'Sermon uploaded', sermon: newSermon });
  } catch (error) {
    res.status(500).json({ error: 'Upload failed' });
  }
};

exports.getSermons = async (req, res) => {
  try {
    const sermons = await Sermon.find().sort({ uploadedAt: -1 });
    res.status(200).json(sermons);
  } catch (error) {
    res.status(500).json({ error: 'Fetching failed' });
  }
};
