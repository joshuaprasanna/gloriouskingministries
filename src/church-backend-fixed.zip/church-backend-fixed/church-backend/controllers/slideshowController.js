const SlideshowImage = require('../models/SlideshowImage');

exports.uploadSlideshowImage = async (req, res) => {
  try {
    const newImage = new SlideshowImage({ imageUrl: req.file.path });
    await newImage.save();
    res.status(201).json({ message: 'Slideshow image uploaded', image: newImage });
  } catch (error) {
    res.status(500).json({ error: 'Upload failed' });
  }
};

exports.getSlideshowImages = async (req, res) => {
  try {
    const images = await SlideshowImage.find().sort({ uploadedAt: -1 });
    res.status(200).json(images);
  } catch (error) {
    res.status(500).json({ error: 'Fetching failed' });
  }
};
