const MarqueeMessage = require('../models/MarqueeMessage');

exports.postMarquee = async (req, res) => {
  try {
    const newMessage = new MarqueeMessage({ message: req.body.message });
    await newMessage.save();
    res.status(201).json({ message: 'Marquee posted', data: newMessage });
  } catch (error) {
    res.status(500).json({ error: 'Post failed' });
  }
};

exports.getMarquees = async (req, res) => {
  try {
    const messages = await MarqueeMessage.find().sort({ postedAt: -1 });
    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ error: 'Fetching failed' });
  }
};
