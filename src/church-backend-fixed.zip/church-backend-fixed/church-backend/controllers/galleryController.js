// const GalleryImage = require('../models/GalleryImage');
// const fs = require('fs');
// const path = require('path');

// exports.uploadImage = async (req, res) => {
//   try {
//     const newImage = new GalleryImage({
//       path: req.file.filename,
//     });
//     await newImage.save();
//     res.status(201).json({ message: 'Image uploaded successfully', image: newImage });
//   } catch (error) {
//     res.status(500).json({ message: 'Image upload failed', error });
//   }
// };

// exports.getGallery = async (req, res) => {
//   try {
//     const images = await GalleryImage.find().sort({ uploadedAt: -1 });
//     res.json(images);
//   } catch (error) {
//     res.status(500).json({ message: 'Failed to fetch gallery images' });
//   }
// };

// exports.deleteImage = async (req, res) => {
//   try {
//     const image = await GalleryImage.findById(req.params.id);
//     if (!image) {
//       return res.status(404).json({ message: 'Image not found' });
//     }

//     // Delete image from disk
//     const filePath = path.join(__dirname, '..', 'uploads', image.path);
//     if (fs.existsSync(filePath)) {
//       fs.unlinkSync(filePath);
//     }

//     await image.deleteOne();
//     res.json({ message: 'Image deleted successfully' });
//   } catch (error) {
//     res.status(500).json({ message: 'Image deletion failed', error });
//   }
// };
// controllers/galleryController.js
const Gallery = require('../models/Gallery');
const fs = require('fs');
const path = require('path');

// ✅ Upload gallery image
const uploadGalleryImage = async (req, res) => {
  try {
    const newImage = new Gallery({
      filename: req.file.filename,
      path: req.file.path,
      createdAt: new Date()
    });
    await newImage.save();
    res.status(201).json({ message: 'Image uploaded successfully', image: newImage });
  } catch (error) {
    res.status(500).json({ message: 'Upload failed', error });
  }
};

// ✅ Get all gallery images
const getGalleryImages = async (req, res) => {
  try {
    const images = await Gallery.find().sort({ createdAt: -1 });
    res.status(200).json(images);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch images', error });
  }
};

// ✅ Delete a gallery image
const deleteGalleryImage = async (req, res) => {
  try {
    const image = await Gallery.findById(req.params.id);
    if (!image) return res.status(404).json({ message: 'Image not found' });

    // Delete image file from uploads
    fs.unlinkSync(path.join(__dirname, '..', image.path));

    await image.deleteOne();
    res.status(200).json({ message: 'Image deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete image', error });
  }
};

module.exports = {
  uploadGalleryImage,
  getGalleryImages,
  deleteGalleryImage
};
