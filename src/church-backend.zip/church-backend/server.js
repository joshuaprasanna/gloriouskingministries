// server.js
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');

// Load .env
dotenv.config();

// App setup
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("✅ MongoDB Connected"))
.catch((err) => console.error("❌ MongoDB Error:", err));

// Routes
app.get('/', (req, res) => {
  res.send('🚀 Church backend running...');
});

// Models & Mail
const Message = require('./models/Message');
const sendMail = require('./mail');

// POST: contact form
app.post('/api/messages', async (req, res) => {
  try {
    const { name, email, message } = req.body;

    // Save to MongoDB
    const newMessage = new Message({ name, email, message });
    await newMessage.save();

    // Send Email Notification
    await sendMail({ name, email, message });

    res.status(201).json({ success: true, message: 'Message received and email sent!' });
  } catch (error) {
    console.error('Save message error:', error);
    res.status(500).json({ success: false, message: 'Failed to save message or send email' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
